# Drop-In Instructions

This package contains starter files for the NoCodeReviewed autonomous microsite foundation.

## How to use

1. Unzip this package.
2. Copy the `docs/` and `data/` folders into the root of your existing NoCodeReviewed project.
3. If files already exist with the same names, compare before overwriting.
4. Give the included docs to Claude as project context.
5. Tell Claude to use `data/tools/index.js` and `data/tools/lovable.js` as starter data, adjusting import/export syntax if your app architecture requires it.

## What this includes

- V1 build strategy
- Tool data model spec
- Lovable ultimate microsite spec
- Scoring methodology
- 28-tool master matrix
- Safe 10-site authority network linking rules
- Next Claude task queue
- Lovable data object
- 28-tool draft data index

## Important

The data records are starter implementation files, not final verified reviews. Only Lovable is filled out in detail. Other tools are intentionally marked draft or coming soon.
