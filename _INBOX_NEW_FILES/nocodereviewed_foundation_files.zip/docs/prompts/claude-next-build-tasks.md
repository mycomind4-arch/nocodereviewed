# Claude Next Build Tasks

Use this queue after the foundation docs and data model exist. Work one task at a time. Do not skip ahead unless the current task builds successfully.

## Task 1: Confirm architecture and route strategy

Goal: Inspect the project and decide whether to keep the static app architecture or migrate to Next.js/App Router.

Files likely involved: `package.json`, `index.html`, `server.mjs`, `src/static-app.js`, `src/styles.css`, existing docs.

Files not to touch: Do not delete existing docs, data, assets, or components.

Acceptance criteria:
- Clear recommendation written to docs.
- Existing build command identified.
- Route strategy documented.

Test command: `npm run build`

Stop condition: Stop if the architecture would require a destructive migration.

## Task 2: Build/refine tool data model

Goal: Create the reusable tool records and data export needed for rendering all tool cards and pages.

Files likely involved: `data/tools/`, `data/tool-master-matrix.md`, tool data model docs.

Acceptance criteria:
- All 28 tools exist as records.
- Lovable record is complete.
- Other records have conservative draft content.
- Status, evidenceStatus, and pricingStatus exist.

Test command: `npm run build`

## Task 3: Build reusable layout and components

Goal: Create reusable page structure without over-engineering.

Components:
- SiteLayout
- Header/Nav
- Footer
- ToolCard
- ScoreBadge
- ScoreGrid
- VerdictCard
- ProsConsGrid
- BestForBadges
- StatusBadge
- EvidenceBadge
- PricingStatusBadge
- CTASection
- FAQAccordion
- PromptCard
- TemplateCard
- ComparisonTable
- ToolSubnav
- PageHero

Acceptance criteria:
- Components are reusable.
- Mobile layout works.
- No unnecessary dependencies.

## Task 4: Build homepage

Goal: Create NoCodeReviewed homepage.

Acceptance criteria:
- NoCodeReviewed is the main brand.
- Vibe Code Authority is described as the testing framework.
- Links to `/tools`, `/tools/lovable`, and `/methodology` exist.

## Task 5: Build /tools index

Goal: List all 28 tools with status badges.

Acceptance criteria:
- Lovable marked flagship/published.
- Other tools clearly draft or coming soon.
- No fake complete reviews.

## Task 6: Build Lovable hub

Goal: Create `/tools/lovable` from Lovable data.

Acceptance criteria:
- Scorecard, verdict, strengths, weaknesses, and subnav appear.
- Links to all Lovable pages.

## Task 7: Build Lovable review page

Goal: Create full Lovable review page.

Acceptance criteria:
- Includes pros, cons, good-fit, bad-fit, alternatives, FAQ, final verdict.

## Task 8: Build Lovable security page

Goal: Create security-readiness page.

Acceptance criteria:
- Includes security score, risks, checklist, evidence disclaimer, and audit prompt.

## Task 9: Build Lovable autonomy page

Goal: Create autonomy scoring page.

Acceptance criteria:
- Clearly states what Lovable can do autonomously and what still needs human review.

## Task 10: Build prompts/templates pages

Goal: Create prompt vault and app blueprint library.

Acceptance criteria:
- Prompt cards include copy-ready text.
- Template cards include pages, data, auth, roles, starter prompt, security checklist, deployment checklist.

## Task 11: Build comparison system

Goal: Build `/tools/lovable/vs/[competitor]` pages for Bolt.new, Replit Agent, and Cursor.

Acceptance criteria:
- Each page has clear choose-this-if sections.
- No fake competitor scores unless data exists.

## Task 12: Add Bolt.new as second full microsite

Goal: Use the Lovable architecture to build Bolt.new next.

Acceptance criteria:
- Bolt.new has full data object.
- All claims marked by evidence status.
- Comparison links connect to Lovable.
