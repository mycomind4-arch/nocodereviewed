# Tool Data Model Spec

The NoCodeReviewed tool system should render review pages from structured tool records. The goal is to make every future tool microsite easier to generate, audit, update, and expand without rebuilding templates.

## Required status fields

```ts
type ContentStatus =
  | 'draft'
  | 'coming-soon'
  | 'needs-evidence'
  | 'needs-review'
  | 'approved'
  | 'published'
  | 'stale'
  | 'retired';

type EvidenceStatus =
  | 'not-started'
  | 'pending-hands-on-testing'
  | 'partially-tested'
  | 'verified'
  | 'needs-update';

type PricingStatus =
  | 'unknown'
  | 'needs-verification'
  | 'manually-verified'
  | 'stale';
```

## TypeScript-style interface

```ts
export interface ToolScoreSet {
  overall: number;
  easeOfUse: number;
  speed: number;
  designQuality: number;
  autonomy: number;
  securityReadiness: number;
  backendReadiness: number;
  productionReadiness: number;
  value: number;
  documentation: number;
  exportControl: number;
}

export interface ToolPricing {
  status: PricingStatus;
  summary: string;
  freePlanNotes?: string;
  paidPlanNotes?: string;
  bestValueNotes?: string;
  hiddenCostWarnings?: string[];
  officialPricingUrl?: string;
}

export interface ToolSecurityReview {
  score: number;
  verdict: string;
  authRisks: string[];
  databaseRisks: string[];
  apiKeyRisks: string[];
  environmentVariableRisks: string[];
  adminRouteRisks: string[];
  paymentRisks: string[];
  deploymentRisks: string[];
  checklist: string[];
}

export interface ToolAutonomyReview {
  score: number;
  verdict: string;
  canDoAutonomously: string[];
  requiresHumanReview: string[];
  bestWorkflows: string[];
  failurePoints: string[];
  oversightChecklist: string[];
}

export interface ToolProductionReadiness {
  score: number;
  verdict: string;
  launchBlockers: string[];
  requiredManualChecks: string[];
  goodSigns: string[];
}

export interface ToolTestScenario {
  name: string;
  status: EvidenceStatus;
  promptUsed?: string;
  expectedOutcome?: string;
  timeToFirstVersion?: string;
  correctionPrompts?: number;
  whatWorked?: string[];
  whatBroke?: string[];
  securityConcerns?: string[];
  deploymentResult?: string;
  finalScore?: number;
}

export interface ToolPrompt {
  title: string;
  useCase: string;
  prompt: string;
  notes?: string;
}

export interface ToolTemplate {
  title: string;
  appConcept: string;
  requiredPages: string[];
  requiredData: string[];
  authNeeds: string[];
  userRoles: string[];
  starterPrompt: string;
  securityChecklist: string[];
  deploymentChecklist: string[];
}

export interface ToolFAQ {
  question: string;
  answer: string;
}

export interface ToolInternalLink {
  label: string;
  href: string;
  reason?: string;
}

export interface ToolCTA {
  label: string;
  href: string;
  type: 'official' | 'affiliate' | 'internal' | 'download' | 'audit';
}

export interface ToolSEO {
  title: string;
  description: string;
  primaryKeyword: string;
  secondaryKeywords?: string[];
}

export interface ToolRecord {
  slug: string;
  name: string;
  category: string;
  tier: 1 | 2 | 3;
  website?: string;
  affiliateUrl?: string;
  shortDescription: string;
  longDescription: string;
  positioning: string;
  primaryUseCase: string;
  audience: string[];
  status: ContentStatus;
  evidenceStatus: EvidenceStatus;
  pricingStatus: PricingStatus;
  lastReviewed?: string;
  lastUpdated: string;
  rating: number;
  scores: ToolScoreSet;
  bestFor: string[];
  notBestFor: string[];
  pros: string[];
  cons: string[];
  competitors: string[];
  pricing: ToolPricing;
  security: ToolSecurityReview;
  autonomy: ToolAutonomyReview;
  productionReadiness: ToolProductionReadiness;
  testLab: ToolTestScenario[];
  prompts: ToolPrompt[];
  templates: ToolTemplate[];
  tutorials: ToolInternalLink[];
  faqs: ToolFAQ[];
  internalLinks: ToolInternalLink[];
  ctas: ToolCTA[];
  seo: ToolSEO;
}
```

## Implementation notes

- Tool records should be stored in a predictable location such as `data/tools/`.
- Lovable should be the first complete record.
- Other tools may use draft records with conservative placeholder scores and clear status labels.
- Do not render draft records as complete reviews.
- Pricing should not be presented as current unless `pricingStatus` is `manually-verified`.
- Test-lab claims should not be presented as completed unless scenario status is `verified` or `partially-tested` with evidence.
