# NoCodeReviewed V1 Build Strategy

## Brand decision

NoCodeReviewed is the primary public-facing website. Vibe Code Authority is the research, scoring, benchmark, and methodology layer that powers NoCodeReviewed ratings.

Recommended public wording:

> NoCodeReviewed ratings are powered by the Vibe Code Authority testing framework.

Use **NoCodeReviewed** for the homepage, navigation, review pages, tool pages, SEO metadata, CTAs, and beginner-facing copy. Use **Vibe Code Authority** for methodology, test lab, security scoring, autonomy scoring, production-readiness scoring, and advanced audit/report language.

## V1 purpose

V1 exists to turn the current project from a static command-center prototype into a real review-site foundation that can scale into a 28-tool authority system.

V1 should not attempt to publish 28 complete review microsites. The correct first milestone is:

1. Build a reusable autonomous microsite engine.
2. Create structured data support for all 28 tools.
3. Build one complete flagship microsite for Lovable.
4. Display other tools honestly as draft, coming-soon, or data-ready.
5. Create methodology and audit-guide pages that support the entire authority model.

## Core principle

Build the autonomous engine, not 28 fake finished sites.

The system should support autonomous generation and updating, but publishing should be controlled by content status, evidence status, and pricing verification status.

## Required V1 routes

```txt
/
/tools
/tools/lovable
/tools/lovable/review
/tools/lovable/pricing
/tools/lovable/security
/tools/lovable/autonomy
/tools/lovable/test-lab
/tools/lovable/prompts
/tools/lovable/templates
/tools/lovable/alternatives
/tools/lovable/vs/bolt-new
/tools/lovable/vs/replit-agent
/tools/lovable/vs/cursor
/tools/lovable/final-verdict
/methodology
/guides/audit-ai-built-apps
```

## V1 content priorities

### Priority 1: Lovable flagship microsite

Lovable should be the first complete tool hub because it is highly relevant to AI-first app building, fast MVPs, SaaS prototypes, dashboards, and nontechnical founders.

Required Lovable pages:

- Hub
- Review
- Pricing
- Security
- Autonomy
- Test Lab
- Prompts
- Templates
- Alternatives
- Lovable vs Bolt.new
- Lovable vs Replit Agent
- Lovable vs Cursor
- Final Verdict

### Priority 2: Methodology

The methodology page must explain the scoring framework and prevent the site from feeling like a thin affiliate site.

It should cover:

- Overall rating
- Ease of use
- Speed
- Design quality
- Autonomy
- Security readiness
- Backend readiness
- Production readiness
- Value
- Documentation
- Export/control
- Evidence status
- Pricing freshness
- Affiliate disclosure
- Uncertainty handling

### Priority 3: Tool index

The `/tools` page should list all 28 tools with status badges. Lovable is complete/flagship. Other tools are draft, coming soon, or data-ready.

### Priority 4: AI-built app audit guide

The guide page should become a practical evergreen authority asset. It should link naturally to the Lovable security page and methodology page.

## V1 technical priorities

1. Preserve the current project structure unless migration is clearly necessary.
2. Create a reusable tool data model.
3. Create data records for all 28 tools.
4. Create reusable components for scorecards, verdict cards, badges, CTAs, FAQ sections, prompt cards, template cards, checklists, and comparison tables.
5. Keep the site mobile-first, readable, and fast.
6. Do not add a database, auth, payment processing, or unnecessary dependencies.
7. Ensure the existing build command still passes.

## What not to build yet

Do not build:

- The full 10-site network
- 28 complete microsites
- Fake completed test-lab results
- Fake screenshots
- Fake pricing tables
- Auth/admin dashboards
- Payment flows
- Affiliate automation
- User accounts
- A full CMS

## Publish status rules

Every tool and major page should support these content statuses:

- `draft`
- `coming-soon`
- `needs-evidence`
- `needs-review`
- `approved`
- `published`
- `stale`
- `retired`

Every evidence-heavy claim should support these evidence statuses:

- `not-started`
- `pending-hands-on-testing`
- `partially-tested`
- `verified`
- `needs-update`

Every pricing area should support these pricing statuses:

- `unknown`
- `needs-verification`
- `manually-verified`
- `stale`

## Definition of done for V1

V1 is done when:

- The homepage clearly positions NoCodeReviewed.
- `/tools` lists the 28 tools with status badges.
- Lovable has a complete multipage microsite.
- Methodology exists and explains the scoring framework.
- The audit guide exists.
- Tool data is structured and reusable.
- Other tools do not pretend to be complete.
- Evidence and pricing statuses prevent misleading claims.
- The site builds successfully.
- The next tool, Bolt.new, can be added mainly by creating data and page content rather than rebuilding architecture.
