# 10-Site Authority Network Linking Rules

## Purpose

The future 10-site network should function as a legitimate owned media network, not a private blog network or backlink scheme. Each site must have standalone value, a distinct search intent, and a real editorial reason to exist.

NoCodeReviewed is the review authority hub. The other sites should support adjacent user needs such as automation, backend/security, SaaS MVPs, AI integration, ecommerce, agencies, SEO/analytics, UI/design, and side-project ideation.

## Network categories

1. NoCodeReviewed / Platform Reviews
2. No-Code Automation & Workflows
3. No-Code Database & Backend
4. No-Code Ecommerce
5. No-Code AI Integration
6. No-Code Agencies
7. No-Code Analytics & SEO
8. No-Code SaaS Founders
9. No-Code Design & UI
10. No-Code Solopreneurs & Side Projects

## Core rules

### 1. Each site must be useful without NoCodeReviewed

A site should not exist only to send links to NoCodeReviewed. It should have its own guides, templates, tools, checklists, case studies, or calculators.

### 2. No sitewide footer backlink network

Do not put followed links to every other property in every footer. A small ownership disclosure or brand network page can exist, but the linking value should come from contextual editorial links.

### 3. No duplicated articles across domains

Do not publish the same article on multiple domains with minor changes. Each domain should own a different search intent.

Bad:

- “Lovable Review” on 10 domains.

Good:

- NoCodeReviewed: “Lovable Review”
- NoCodeBackend: “Lovable Supabase Security Checklist”
- NoCodeSaaS: “Can Lovable Build a SaaS MVP?”
- NoCodeUI: “Lovable UI Quality Test”
- NoCodeAutomation: “How to Connect a Lovable App to Make”

### 4. Contextual links only

Links should appear where they genuinely help the reader.

Good example:

> Before launching an AI-built SaaS, compare the tool’s production-readiness rating on NoCodeReviewed.

Bad example:

> Best no-code tools best no-code tools best no-code tools.

### 5. Deep links preferred

Most links should point to specific useful pages, not just the NoCodeReviewed homepage.

Examples:

- `/tools/lovable/security`
- `/tools/bolt-new/review`
- `/guides/audit-ai-built-apps`
- `/methodology`
- `/tools/lovable/vs/bolt-new`

### 6. Avoid exact-match anchor spam

Use natural anchors.

Good:

- NoCodeReviewed
- NoCodeReviewed’s Lovable security review
- this AI-built app audit checklist
- the production-readiness methodology

Avoid repeated anchors like:

- best no-code app builder
- Lovable review
- Bolt.new review

### 7. Each domain must serve a different search intent

NoCodeReviewed should own reviews and comparisons. Other domains should own implementation, workflows, strategy, templates, and adjacent use cases.

### 8. No automated cross-link blocks

Do not add mechanical “related sites” blocks that appear identically on every page. Use editorial links inside relevant content.

### 9. Each site should earn its own external links

Every domain should eventually have linkable assets such as free templates, calculators, public benchmarks, GitHub repos, downloadable checklists, or prompt packs.

### 10. Link both directions selectively

NoCodeReviewed can link out to a specialized site when that site has the better implementation guide. Satellite sites can link back to NoCodeReviewed when a review, comparison, or scoring page is the best next resource.

## Safe launch order

1. NoCodeReviewed
2. NoCodeBackend
3. NoCodeSaaS
4. NoCodeAIApps
5. NoCodeUI

Only expand beyond these after the first properties have real content and some external validation.
