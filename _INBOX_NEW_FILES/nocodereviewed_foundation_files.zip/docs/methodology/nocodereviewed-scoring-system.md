# NoCodeReviewed Scoring System

NoCodeReviewed ratings are powered by the Vibe Code Authority testing framework. The goal is to evaluate whether a no-code or AI app-building tool can help users create something that is not only visually impressive, but also usable, maintainable, secure, and launch-ready.

## Scoring categories

Scores use a 10-point scale. A high score does not mean a tool is perfect. It means the tool performs strongly for its intended use case compared with alternatives.

## Overall Rating

Measures the combined recommendation strength after considering speed, ease of use, design quality, autonomy, security readiness, backend readiness, production readiness, value, documentation, and export/control.

- 10/10: Category-leading and unusually complete across most dimensions.
- 8/10: Strong recommendation with known limitations.
- 6/10: Useful but situation-dependent.
- 4/10: Significant limitations for most users.
- 2/10: Not recommended except for narrow experiments.

Evidence: hands-on tests, documentation review, generated app quality, deployment workflow, user-control limits, pricing/value, and competitor comparison.

## Ease of Use

Measures how quickly a target user can start, understand, and make progress.

- 10/10: Clear onboarding, low friction, strong defaults, beginner-friendly.
- 8/10: Easy for most users with minor learning curve.
- 6/10: Usable, but setup or concepts may confuse beginners.
- 4/10: Requires technical comfort or repeated troubleshooting.
- 2/10: Hard to use without substantial prior knowledge.

Evidence: onboarding flow, UI clarity, setup steps, error recovery, documentation quality.

## Speed

Measures time from idea to usable first version.

- 10/10: Produces a coherent first version in minutes.
- 8/10: Fast with several prompt iterations or setup steps.
- 6/10: Moderate speed but requires manual cleanup.
- 4/10: Slow workflow or frequent blockers.
- 2/10: Too slow for its promised use case.

Evidence: test prompts, time to first version, correction prompts, setup overhead.

## Design Quality

Measures visual polish, layout quality, UX patterns, responsive behavior, and consistency.

- 10/10: Produces polished, modern, responsive interfaces consistently.
- 8/10: Strong visual output with minor cleanup required.
- 6/10: Acceptable but generic or inconsistent.
- 4/10: Requires heavy design intervention.
- 2/10: Poor or broken UI output.

Evidence: generated pages, mobile checks, layout consistency, accessibility basics.

## Autonomy

Measures how much the tool can accomplish without constant human intervention.

- 10/10: Can plan, generate, debug, iterate, and deploy complex workflows with minimal guidance.
- 8/10: Strong autonomous generation and iteration, but still needs review.
- 6/10: Handles simple tasks well but struggles with complexity.
- 4/10: Requires frequent manual direction.
- 2/10: Mostly a manual tool with limited autonomous help.

Evidence: prompt follow-through, error handling, multi-step task completion, debugging ability.

## Security Readiness

Measures whether apps created with the tool are likely to be safe enough for launch without major review.

- 10/10: Strong security defaults, clear auth/database protection, safe secret handling, strong deployment guidance.
- 8/10: Good defaults, but manual verification still required.
- 6/10: Can be safe if configured correctly, but risks are common.
- 4/10: High risk without experienced review.
- 2/10: Unsafe defaults or unclear security model.

Evidence: auth behavior, database rules, API key handling, environment variables, admin routes, payment flows, error messages.

## Backend Readiness

Measures whether the tool can support real app logic, data persistence, roles, integrations, and scaling patterns.

- 10/10: Strong backend architecture, database support, auth, integrations, and maintainable logic.
- 8/10: Good backend support with some limitations.
- 6/10: Adequate for MVPs and simple apps.
- 4/10: Backend capability is shallow or fragile.
- 2/10: Mostly frontend-only or unsuitable for real app workflows.

Evidence: database model, auth setup, API integrations, role handling, server-side logic.

## Production Readiness

Measures the gap between a good-looking prototype and a launch-ready application.

- 10/10: Strong path to production with testing, deployment, security, error states, responsiveness, and maintainability.
- 8/10: Launchable with a clear review checklist.
- 6/10: Good prototype; production requires meaningful cleanup.
- 4/10: Large gap between demo and launch.
- 2/10: Not production-suitable for most projects.

Evidence: deployment flow, generated code quality, error states, loading states, mobile checks, testing, security review.

## Value

Measures cost relative to capability and alternatives.

- 10/10: Excellent value for target users.
- 8/10: Worth paying for in common use cases.
- 6/10: Fair value with limitations.
- 4/10: Expensive for the output or use case.
- 2/10: Poor value compared with alternatives.

Evidence: pricing tiers, plan limits, output quality, time saved, competitor pricing.

## Documentation

Measures help quality, learning resources, examples, docs structure, and support readiness.

- 10/10: Excellent docs, clear examples, strong support resources.
- 8/10: Good docs for most workflows.
- 6/10: Adequate but incomplete.
- 4/10: Sparse, confusing, or outdated.
- 2/10: Documentation blocks effective use.

Evidence: official docs, tutorials, API/reference clarity, community support.

## Export/Control

Measures user control over code, data, hosting, portability, and lock-in.

- 10/10: Strong export, code ownership, self-hosting or flexible deployment, minimal lock-in.
- 8/10: Good control with some platform dependency.
- 6/10: Moderate control; acceptable for many users.
- 4/10: Significant lock-in or limited export.
- 2/10: Poor ownership or portability.

Evidence: export options, code access, database portability, hosting flexibility, vendor lock-in.

## Editorial disclosure rules

NoCodeReviewed should disclose when a page includes affiliate links, sponsored placements, or unverified claims. Ratings should not be changed solely because of affiliate relationships.

## Pricing freshness rules

Pricing changes frequently. Pricing sections must include a verification status and should direct users to official pricing pages for current limits.

## Evidence status rules

A test result is only marked verified if there is documented evidence. If testing has not happened, pages should use labels such as “pending hands-on testing” or “planned test framework.”

## Handling uncertainty

When evidence is incomplete, state the uncertainty directly. Do not fill gaps with confident language. Use conditional wording and mark pages as needs-evidence or needs-review.

## Prototype warning

A polished generated interface is not the same as a production-ready application. Production readiness requires auth review, database review, secret handling, error states, mobile QA, deployment checks, and security validation.
