# NoCodeReviewed Expansion Pack Instructions

This package adds content, prompt, SEO, QA, component-spec, empire, admin-spec, and second-wave tool planning files.

## How To Use
1. Unzip this package.
2. Copy the `docs/` and `data/` folders into the NoCodeReviewed project.
3. If files already exist, compare before overwriting.
4. Give Claude one task prompt at a time from `docs/prompts/`.
5. Keep Lovable as the only complete flagship microsite until evidence exists for other tools.

## Recommended Claude Order
1. claude-task-01-inspect-project.md
2. claude-task-02-create-route-system.md
3. claude-task-03-build-data-model.md
4. claude-task-04-build-homepage-tools-index.md
5. claude-task-05-build-lovable-hub.md
6. Continue one task at a time.

## Rule
Build the autonomous engine, not 28 fake finished reviews.
