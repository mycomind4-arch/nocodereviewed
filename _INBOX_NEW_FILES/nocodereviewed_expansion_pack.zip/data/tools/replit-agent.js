export const replit_agent = {
  slug: "replit-agent",
  name: "Replit Agent",
  category: "AI App Builder",
  tier: 1,
  status: "coming-soon",
  evidenceStatus: "pending-hands-on-testing",
  pricingStatus: "needs-verification",
  shortDescription: "Draft NoCodeReviewed profile for Replit Agent.",
  positioning: "Replit Agent is a AI agent inside a broader coding and deployment environment.",
  primaryUseCase: "AI-assisted app building",
  scores: { overall: null, easeOfUse: null, speed: null, designQuality: null, autonomy: null, securityReadiness: null, backendReadiness: null, productionReadiness: null, value: null, documentation: null, exportControl: null },
  bestFor: [],
  notBestFor: [],
  competitors: ["lovable", "cursor", "replit-agent", "bolt-new"].filter(s => s !== "replit-agent"),
  lastUpdated: "2026-05-29"
};
