export const bolt_new = {
  slug: "bolt-new",
  name: "Bolt.new",
  category: "AI App Builder",
  tier: 1,
  status: "coming-soon",
  evidenceStatus: "pending-hands-on-testing",
  pricingStatus: "needs-verification",
  shortDescription: "Draft NoCodeReviewed profile for Bolt.new.",
  positioning: "Bolt.new is a browser-based AI app builder with stronger code-oriented workflow.",
  primaryUseCase: "AI-assisted app building",
  scores: { overall: null, easeOfUse: null, speed: null, designQuality: null, autonomy: null, securityReadiness: null, backendReadiness: null, productionReadiness: null, value: null, documentation: null, exportControl: null },
  bestFor: [],
  notBestFor: [],
  competitors: ["lovable", "cursor", "replit-agent", "bolt-new"].filter(s => s !== "bolt-new"),
  lastUpdated: "2026-05-29"
};
