# Claude Task 08-build-prompts-templates

## Goal
Build Lovable prompts and templates pages using reusable cards and copy-ready content.

## Required Behavior
- Inspect relevant files before editing.
- Preserve existing docs and data.
- Keep NoCodeReviewed as the main brand.
- Use Vibe Code Authority only as the methodology/testing framework.
- Do not invent completed tests, pricing, screenshots, or security results.

## Acceptance Criteria
- The task is completed with minimal unnecessary changes.
- Existing build command still passes, or exact build failure is documented.
- All new claims are either generic, clearly marked as pending verification, or backed by existing project evidence.
- A concise final summary lists files changed, risks, and next step.

## Stop Conditions
- Stop if the required change demands a major framework migration not explicitly approved.
- Stop if build failures appear unrelated and risky to fix blindly.
- Stop if source files conflict with the requested architecture.
