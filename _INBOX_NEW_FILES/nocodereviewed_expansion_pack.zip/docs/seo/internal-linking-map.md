# Internal Linking Map

## Global Links
Homepage links to /tools, /methodology, /guides/audit-ai-built-apps, and /tools/lovable.

## Lovable Links
Every Lovable page links back to /tools/lovable and to the most relevant next decision page.

## High-Value Link Paths
- /tools/lovable/security -> /guides/audit-ai-built-apps
- /tools/lovable/autonomy -> /methodology
- /tools/lovable/prompts -> /tools/lovable/templates
- /tools/lovable/alternatives -> /tools/lovable/vs/bolt-new
- /tools/lovable/final-verdict -> /tools/lovable/security
