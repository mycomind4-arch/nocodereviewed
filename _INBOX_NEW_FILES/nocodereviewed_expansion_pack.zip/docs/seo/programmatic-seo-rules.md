# Programmatic SEO Rules

Programmatic pages must be data-driven, useful, and honest.

## Do
- Use unique intent per page.
- Display status and evidence fields.
- Link to methodology.
- Use structured data cautiously.
- Keep draft pages out of aggressive SEO indexing if they are thin.

## Do Not
- Generate 28 fake finished reviews.
- Duplicate the same article with swapped tool names.
- Invent pricing or testing evidence.
- Publish comparison pages without meaningful decision logic.
