# NoCodeReviewed SEO Site Architecture

## Primary Hubs
- /tools
- /methodology
- /guides/audit-ai-built-apps
- /tools/[slug]

## Tool Microsite Pattern
- /tools/[slug]
- /tools/[slug]/review
- /tools/[slug]/pricing
- /tools/[slug]/security
- /tools/[slug]/autonomy
- /tools/[slug]/test-lab
- /tools/[slug]/prompts
- /tools/[slug]/templates
- /tools/[slug]/alternatives
- /tools/[slug]/vs/[competitor]
- /tools/[slug]/final-verdict

## Cannibalization Rule
Each page must own a different intent. Do not make every page target the same generic review keyword.
