# Schema Markup Plan

Use schema only where the visible page content supports it.

## Candidate Types
- SoftwareApplication for complete tool pages.
- Review for completed, approved reviews only.
- FAQPage for pages with visible FAQs.
- BreadcrumbList for navigational hierarchy.
- Article for guides.

## Rules
Do not add review schema to draft pages. Do not add fake aggregate ratings. Do not mark pending test templates as completed reviews.
