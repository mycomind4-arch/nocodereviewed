# URL Rules

Use lowercase slugs, hyphens, and stable URLs.

Preferred:
- /tools/lovable
- /tools/bolt-new
- /tools/replit-agent
- /tools/v0-vercel
- /tools/lovable/vs/bolt-new

Avoid:
- Date-based URLs for evergreen reviews.
- Random generated slugs.
- Changing slugs after launch unless redirects are added.
