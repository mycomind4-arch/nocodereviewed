# Pre Publish Review Checklist

Before publishing: build passes, links work, mobile readable, claims reviewed, CTAs correct, metadata present.

## Required Checks
- Brand is NoCodeReviewed.
- Vibe Code Authority is used only as methodology/testing framework.
- No fake tests, pricing, screenshots, or security claims.
- Page has a clear search intent.
- Page has helpful internal links.
- Page status is visible where appropriate.
