# Evidence Status Rules

Evidence labels control trust. Pending templates are not completed tests.

## Required Checks
- Brand is NoCodeReviewed.
- Vibe Code Authority is used only as methodology/testing framework.
- No fake tests, pricing, screenshots, or security claims.
- Page has a clear search intent.
- Page has helpful internal links.
- Page status is visible where appropriate.
