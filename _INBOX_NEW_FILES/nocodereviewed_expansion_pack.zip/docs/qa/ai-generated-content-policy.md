# Ai Generated Content Policy

AI may draft content, but factual claims require verification. Do not publish automated content that is thin, duplicated, or misleading.

## Required Checks
- Brand is NoCodeReviewed.
- Vibe Code Authority is used only as methodology/testing framework.
- No fake tests, pricing, screenshots, or security claims.
- Page has a clear search intent.
- Page has helpful internal links.
- Page status is visible where appropriate.
