# Pricing Verification Checklist

Pricing must be marked unknown, needs-verification, manually-verified, or stale. Link users to official pricing.

## Required Checks
- Brand is NoCodeReviewed.
- Vibe Code Authority is used only as methodology/testing framework.
- No fake tests, pricing, screenshots, or security claims.
- Page has a clear search intent.
- Page has helpful internal links.
- Page status is visible where appropriate.
