# Content Quality Gate

Every page must have unique purpose, useful sections, clear status, internal links, and no fake claims.

## Required Checks
- Brand is NoCodeReviewed.
- Vibe Code Authority is used only as methodology/testing framework.
- No fake tests, pricing, screenshots, or security claims.
- Page has a clear search intent.
- Page has helpful internal links.
- Page status is visible where appropriate.
