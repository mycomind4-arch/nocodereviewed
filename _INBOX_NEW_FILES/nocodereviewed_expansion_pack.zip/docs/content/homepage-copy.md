# NoCodeReviewed Homepage Copy

## Hero
Independent reviews of AI app builders, no-code platforms, and vibe-coding tools.

## Subheadline
NoCodeReviewed evaluates tools for speed, autonomy, security readiness, backend readiness, and whether the apps they create are actually launch-ready.

## Primary CTAs
- Browse Tools
- View Lovable Review
- Read Methodology

## Authority Positioning
NoCodeReviewed ratings are powered by the Vibe Code Authority testing framework: a practical scoring system focused on security, autonomy, production readiness, and real-world launch risk.

## Authority Pillars
1. Security readiness: Can the generated app protect users, data, secrets, and admin routes?
2. Autonomy scoring: How far can the tool go without constant human intervention?
3. Production readiness: Does the result merely look finished, or is it ready for real users?
4. Test labs: Standardized build scenarios for comparing tools honestly.
5. Prompt/template vaults: Practical prompts and blueprints users can actually use.

## Homepage Sections
- Hero
- Featured flagship review: Lovable
- Browse priority tools
- Why normal reviews are not enough
- Vibe Code Authority methodology
- Latest guides
- Final CTA
