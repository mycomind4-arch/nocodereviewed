# Lovable Prompt Vault

    **Purpose:** Prompt library copy.

    ## Core Copy Blocks
    - Prompt vault principle: be specific about users, pages, data, roles, business rules, and acceptance criteria.
- Each prompt should be paired with a follow-up audit prompt.
- Include copy-ready prompts for SaaS MVP, dashboard, marketplace, client portal, auth, database, error fixing, deployment, and security audit.
- Prompts should teach users how to build responsibly, not just quickly.

    ## Recommended On-Page Structure
    1. Hero verdict
    2. Evidence/status disclosure
    3. Main explanation
    4. Score or checklist section
    5. Practical next step
    6. Internal links to related Lovable pages
    7. CTA

    ## Internal Links
    - /tools/lovable
    - /tools/lovable/security
    - /tools/lovable/autonomy
    - /tools/lovable/prompts
    - /tools/lovable/final-verdict
    - /methodology
    - /guides/audit-ai-built-apps

    ## CTA Copy
    Use Lovable for fast MVP creation, but run the NoCodeReviewed launch-readiness checklist before treating the app as production-ready.
