# Methodology Page Copy

NoCodeReviewed ratings are powered by the Vibe Code Authority testing framework.

The framework scores tools across ease of use, speed, design quality, autonomy, security readiness, backend readiness, production readiness, value, documentation, and export/control.

The core principle: a tool can be excellent for prototyping and still require serious review before launch.

## Editorial Rules
- Do not claim completed testing without evidence.
- Do not hardcode pricing unless manually verified.
- Disclose affiliate relationships clearly.
- Mark uncertainty openly.
- Distinguish visual polish from production readiness.

## Evidence Statuses
- not-started
- pending-hands-on-testing
- partially-tested
- verified
- needs-update

## Pricing Statuses
- unknown
- needs-verification
- manually-verified
- stale
