# How to Audit an AI-Built App Before Launch

AI-built apps can look finished before they are safe. A polished dashboard does not prove that authentication, database rules, API keys, admin routes, payments, and deployment settings are correct.

## Auth Checklist
- Signup, login, logout, and password reset work correctly.
- Private pages redirect logged-out users.
- Direct URL access does not bypass auth.
- Role-based pages are tested with multiple accounts.

## Database Checklist
- Users can only read their own private records.
- Users can only write allowed fields.
- Admin-only tables are blocked from normal users.
- Public data is intentionally public.

## Environment Variable Checklist
- API keys are not visible in frontend code.
- Secrets are stored in deployment environment settings.
- Local .env files are not committed.

## AI Audit Prompt
Audit this app before launch. Check authentication, private routes, database access rules, API key exposure, environment variables, admin routes, payment/webhook validation, error messages, input validation, mobile layout, and deployment configuration. Return a severity-ranked list of issues, exact files to inspect, suggested fixes, and a final launch-readiness verdict.
