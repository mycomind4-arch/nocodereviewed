# Tool Card Spec

## Purpose
Tool directory card showing name, tier, category, status, evidence status, short description, primary use case, and link.

## Required Props / Fields
- title
- description
- status or variant where relevant
- internal link or CTA where relevant

## Design Requirements
- Premium dark SaaS style.
- Mobile-first layout.
- High contrast text.
- Clear visual hierarchy.
- Cyan for neutral highlights, green for positive, orange for caution, red only for genuine risk.

## Acceptance Criteria
- Component is reusable across all tool microsites.
- Component does not hardcode Lovable unless it is a Lovable-specific page.
- Component works with draft/status fields.
- Component does not create misleading claims.
