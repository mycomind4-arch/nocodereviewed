# Faq Accordion Spec

## Purpose
Accessible FAQ component with question, answer, and optional internal link.

## Required Props / Fields
- title
- description
- status or variant where relevant
- internal link or CTA where relevant

## Design Requirements
- Premium dark SaaS style.
- Mobile-first layout.
- High contrast text.
- Clear visual hierarchy.
- Cyan for neutral highlights, green for positive, orange for caution, red only for genuine risk.

## Acceptance Criteria
- Component is reusable across all tool microsites.
- Component does not hardcode Lovable unless it is a Lovable-specific page.
- Component works with draft/status fields.
- Component does not create misleading claims.
