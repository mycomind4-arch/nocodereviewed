# Bolt.new Ultimate Microsite Spec

## Status
Draft specification for the second-wave tool microsite.

## Positioning
Bolt.new is positioned as a browser-based AI app builder with stronger code-oriented workflow.

## Planned Routes
- /tools/bolt-new
- /tools/bolt-new/review
- /tools/bolt-new/pricing
- /tools/bolt-new/security
- /tools/bolt-new/autonomy
- /tools/bolt-new/test-lab
- /tools/bolt-new/prompts
- /tools/bolt-new/templates
- /tools/bolt-new/alternatives
- /tools/bolt-new/final-verdict

## Required Warnings
Do not publish as complete until hands-on evidence, pricing verification, and editorial review are finished.
