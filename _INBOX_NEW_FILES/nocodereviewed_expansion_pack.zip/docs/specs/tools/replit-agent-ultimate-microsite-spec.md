# Replit Agent Ultimate Microsite Spec

## Status
Draft specification for the second-wave tool microsite.

## Positioning
Replit Agent is positioned as a AI agent inside a broader coding and deployment environment.

## Planned Routes
- /tools/replit-agent
- /tools/replit-agent/review
- /tools/replit-agent/pricing
- /tools/replit-agent/security
- /tools/replit-agent/autonomy
- /tools/replit-agent/test-lab
- /tools/replit-agent/prompts
- /tools/replit-agent/templates
- /tools/replit-agent/alternatives
- /tools/replit-agent/final-verdict

## Required Warnings
Do not publish as complete until hands-on evidence, pricing verification, and editorial review are finished.
